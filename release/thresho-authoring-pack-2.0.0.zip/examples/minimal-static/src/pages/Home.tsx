import { Content } from "@thresho/site-sdk";
export default function Home() { return <main><section className="hero" nodeId="home-hero"><h1><Content.Text field="title" /></h1><p><Content.Text field="body" /></p></section><section className="body"><p>A small static starting point.</p></section></main>; }
