# format 2 authoring guide (pack 2.0.0)

This guide describes the bounded presentation source format that thresho compiles into a storefront. Everything here is enforced by the compiler; anything not described is rejected, never approximated.

## 1. What a package is

A package is a manifest (`thresho.site.json`) plus source files under `src/`: page and component files written in a bounded TSX subset, and plain CSS. The compiler turns it into a static definition; the catalog, prices, stock, cart and checkout come from thresho at runtime and are never written in source.

Every saved source revision is pinned to the compiler identity that built it. If the current compiler builds a saved revision differently, the workspace asks you to rebuild it, which creates a new revision from the same source.

## 2. Manifest

Required keys: `kind` (`thresho.website.source`), `formatVersion` (2), `id` (lowercase, 1 to 64 characters), `name` (1 to 160 characters), `journeys` (one or more journey contracts; this pack supports `presentation-retail-journey.v2`), `routes`, `content`. Optional: `locales` (`default` plus `supported`, 1 to 8 unique tags), `styles` (the list of stylesheet paths), `fonts`, `media`, `forms` and `extension` (the declared extension surface). The complete JSON Schema is `schema/source.schema.json`.

`locales` is optional. Absent means one language, `en`. When present, `default` must be one of `supported`. thresho serves the default tag at the authored paths (`/about`) and every non-default tag under its own first segment (`/fr/about`, `/fr/shop`, `/fr/shop/<key>`). The source never writes that segment. The compiler enforces the default membership and the content-key membership; the JSON Schema checks the shape, tag pattern and bounds only.

`content` is a map of text fields your pages read with `<Content.Text field="..." />`. A value is a plain string for every locale, or a map with one value per declared tag. A map must include the default tag; a missing non-default tag falls back to the default value. The values you ship are defaults; each site replaces the default-locale values in its own settings.

## 3. Routes, roles and journeys

Each route has a `path`, an `entry` page file, an optional `capability` (`commerce.discovery`, `commerce.productPurchase`, `commerce.cart`) and an optional `role` (`home`, `content`, `catalog`, `product`, `cart`, `checkout`, `confirmation`, `account`, `notFound`).

Protected first path segments: `__draft`, `__portal-preview`, `__published-snapshot`, `__site-build-preview`, `__thresho`, `__variant-preview`, `account`, `api`, `auth`, `cart`, `checkout`, `classes`, `confirmation`, `email`, `events`, `feed.xml`, `internal`, `login`, `logout`, `newsletter`, `og-image`, `order`, `pay`, `portal`, `preview`, `review`, `robots.txt`, `sitemap.xml`, `stock-alerts`, and any path starting with `/:`. Whole paths (without the leading `/`, any letter case) matching `^sitemap-[^/]+\.xml$`, `^book/confirmed$`, `^join/confirmed$` are protected too. Reserved prefixes `/__thresho/`, `/.well-known/`, `/feeds/` and reserved root files `/robots.txt`, `/sitemap.xml`, `/feed.xml`, `/manifest.json`, `/sw.js`, `/favicon.ico`, `/agents.md`, `/llms.txt`, `/health`, `/ready` are refused too.

- Declare a role on every route or on none. A package without roles has no customer journey and cannot be submitted for review.

- The journey profile is retail.transactional when any route has role cart, checkout, confirmation, account; otherwise retail.catalog when any route has role catalog, product; otherwise content.

- A content journey requires routes with roles home.

- A retail.catalog journey requires routes with roles home, catalog, product.

- A retail.transactional journey requires routes with roles home, catalog, product, cart, checkout.

- In a retail.transactional journey the home, catalog, product routes must each contain a plain link to the cart route path.

- In a retail.transactional journey the cart route must contain Cart.Lines, Cart.LineQuantity, Cart.LineRemove, Cart.Total, Cart.Checkout.

- In a retail.transactional journey the checkout route must contain Checkout.Root.

- In a retail.transactional journey the product route must contain Product.QuickAdd.

- In a retail.transactional journey the product route must hold exactly one Product.Price, Product.PurchaseTerms: they carry the required tax, pickup and return notices (DISCLOSURE_REQUIRED or DISCLOSURE_DUPLICATED names the placement).

- In a retail.transactional journey the checkout route must hold the Checkout.Root, Checkout.Fulfillment, Checkout.Summary, Checkout.Submit: they carry the required tax, pickup and return notices (DISCLOSURE_REQUIRED or DISCLOSURE_DUPLICATED names the placement).

- Never hide a required notice: Product.Price, Product.PurchaseTerms and the checkout slots, and every element around them, reject hidden, inert, aria-hidden, style and data-design-visibility (DISCLOSURE_HIDDEN). Product.Price and Product.PurchaseTerms take no children or unregistered design properties, and no stylesheet rule may select data-thresho-disclosure (DISCLOSURE_OVERRIDDEN). A notice hidden by other CSS disables adding to the cart and flags the page.

- Never target the cookie consent banner, which thresho adds to every published page. No stylesheet rule may select a data-thresho-consent attribute or a class or ID that starts with thresho-consent, and no element may take a className token or an id that starts with thresho-consent (CONSENT_OVERRIDDEN).

- Never give an element an id that starts with site-source-, which thresho reserves for its hydration payload and root (RESERVED_ELEMENT_ID).

- Declare optional `locales` with `default` and `supported` (1 to 8 unique tags such as en, fr or fr-CA). thresho serves the default tag at the authored paths and every non-default tag under its own first segment, so no authored route may start with a declared tag (INVALID_LOCALE). A route path may not end with a slash (INVALID_ROUTE).

- Give every route whose role is absent, home, content, catalog or product a seo object: seo.title and seo.description name content fields with non-empty text (SEO_TITLE_REQUIRED, SEO_DESCRIPTION_REQUIRED). Keep the title to 10 to 60 characters and the description to 50 to 160 (SEO_TITLE_LENGTH and SEO_DESCRIPTION_LENGTH are suggestions, not errors). seo.ogImage names an image slot and seo.noindex: true keeps a route out of search. Cart, checkout, confirmation and account routes take no seo object. A product route has exactly one final parameter.

- A notFound route is optional. When present it uses the path /404, takes no capability and no seo object, and serves every unknown path with status 404. A package has zero or one notFound route.

- The path /cart is protected and may only be used by the route with role cart.

- The path /checkout is protected and may only be used by the route with role checkout.

- The path /confirmation is protected and may only be used by the route with role confirmation.

- The presentation-retail-journey.v2 journey adds the product checkout line. It holds stock units for every retail variant line, at the order's fulfillment location. The hold expires after 900 seconds. Release rule: A paid order deletes the hold and decrements the stock; a new payment attempt deletes and replaces it; the sweeper deletes an expired hold.

- The presentation-retail-journey.v2 journey owns these route roles: home, content, catalog, product, cart, checkout, confirmation, account, notFound.

- The compiler writes compiler version site-source-compiler/10 on every package. Review and release require a complete journey.

## 4. Required controls per role

| Role | Must contain (retail.transactional journeys) |
| --- | --- |
| cart | `Cart.Lines`, `Cart.LineQuantity`, `Cart.LineRemove`, `Cart.Total`, `Cart.Checkout` |
| checkout | `Checkout.Root` |
| product | `Product.QuickAdd` |

## 5. SDK components and props

Import components only from `@thresho/site-sdk`. Every component also accepts `nodeId`, a stable identity for design controls.

| Component | Props |
| --- | --- |
| `Content.Text` | `field`, `nodeId` |
| `Catalog.Root` | `className`, `nodeId` |
| `Catalog.Products` | `className`, `item`, `nodeId` |
| `Catalog.ResultCount` | `className`, `nodeId` |
| `Catalog.Filters` | `className`, `data-design-facet-search`, `nodeId` |
| `Catalog.PriceRange` | `className`, `nodeId` |
| `Catalog.SelectedFilters` | `className`, `nodeId` |
| `Catalog.Sort` | `className`, `label`, `nodeId` |
| `Catalog.Categories` | `className`, `label`, `nodeId` |
| `Catalog.FilterPanel` | `className`, `label`, `nodeId` |
| `Catalog.ClearFilters` | `className`, `label`, `nodeId` |
| `Catalog.Search` | `className`, `label`, `nodeId` |
| `Catalog.Pickup` | `className`, `label`, `nodeId` |
| `Catalog.LoadMore` | `className`, `nodeId` |
| `Catalog.Status` | `className`, `nodeId` |
| `Product.Link` | `className`, `nodeId` |
| `Product.Image` | `className`, `nodeId` |
| `Product.QuickAdd` | `className`, `nodeId` |
| `Product.Options` | `className`, `nodeId` |
| `Product.Name` | `className`, `nodeId` |
| `Product.Description` | `className`, `nodeId` |
| `Product.CompareAtPrice` | `className`, `nodeId` |
| `Product.Rating` | `className`, `nodeId` |
| `Product.Badge` | `className`, `nodeId` |
| `Product.Pickup` | `className`, `label`, `nodeId` |
| `Product.Price` | `className`, `nodeId` |
| `Product.PurchaseTerms` | `className`, `nodeId` |
| `Product.Availability` | `className`, `nodeId` |
| `Product.GalleryImage` | `className`, `label`, `nodeId` |
| `Product.GalleryThumbnails` | `className`, `label`, `nodeId` |
| `Product.GalleryPrevious` | `className`, `label`, `nodeId` |
| `Product.GalleryNext` | `className`, `label`, `nodeId` |
| `Product.Specifications` | `className`, `label`, `nodeId` |
| `Cart.Summary` | `className`, `label`, `nodeId` |
| `Cart.Lines` | `className`, `label`, `nodeId` |
| `Cart.LineQuantity` | `className`, `label`, `nodeId` |
| `Cart.LineRemove` | `className`, `label`, `nodeId` |
| `Cart.Adjustment` | `className`, `label`, `nodeId` |
| `Cart.Total` | `className`, `label`, `nodeId` |
| `Cart.Checkout` | `className`, `label`, `nodeId` |
| `Checkout.Root` | `className`, `nodeId` |
| `Checkout.Coordinator` | `className`, `nodeId` |
| `Checkout.Contact` | `className`, `label`, `nodeId` |
| `Checkout.Fulfillment` | `className`, `label`, `nodeId` |
| `Checkout.Summary` | `className`, `label`, `nodeId` |
| `Checkout.Payment` | `className`, `label`, `nodeId` |
| `Checkout.Submit` | `className`, `label`, `nodeId` |
| `Checkout.Status` | `className`, `label`, `nodeId` |
| `Checkout.Confirmation` | `className`, `label`, `nodeId` |
| `Product.SKU` | `className`, `nodeId` |
| `Presentation.Image` | `className`, `slot`, `alt`, `nodeId` |
| `Presentation.Video` | `className`, `slot`, `label`, `nodeId` |
| `Presentation.Icon` | `className`, `name`, `nodeId` |
| `Form.Contact` | `form`, `className`, `nodeId` |
| `Form.Lead` | `form`, `className`, `nodeId` |
| `Form.Newsletter` | `form`, `className`, `nodeId` |
| `Form.Booking` | `form`, `className`, `nodeId` |
| `Form.Review` | `form`, `className`, `nodeId` |

The importer stamps a `nodeId` on every JSX element that has none. An authored `nodeId` is kept. Stamping is deterministic and idempotent, so an existing element keeps its identity when another element is inserted.

A component instance composes page identity. A nested instance takes `<outer instance id>-<inner instance id>`. The first root of a component renders as the instance page ID. Every other root and every descendant renders as `<instance page id>-<nodeId>`. A composed page ID longer than 80 characters becomes `h` plus 20 hexadecimal characters of its SHA-256 digest.

An extension anchor or region that names a node inside a component instance must name that composed page ID. An element operation always names the source `nodeId`, never the composed page ID.

A source element that renders on no route is not addressable. Remove dead markup before you publish.

`data-design-facet-search` applies only to `Catalog.Filters` and controls every choice facet in that instance. Search is on by default when the attribute is absent. The five accepted forms are `data-design-facet-search`, `data-design-facet-search="true"`, `data-design-facet-search="false"`, `data-design-facet-search={true}` and `data-design-facet-search={false}`. Bare and true forms enable search; false forms disable search. Use an explicit unique `nodeId` to make the attribute patchable in the workspace. The workspace does not insert an absent attribute.

## 6. Design controls

Attributes the workspace can edit without touching your code. Put them on an element with an explicit `nodeId`.

| Attribute | Kind | Minimum | Maximum |
| --- | --- | --- | --- |
| `data-design-columns` | integer | 1 | 12 |
| `data-design-columns-tablet` | integer | 1 | 12 |
| `data-design-columns-mobile` | integer | 1 | 12 |
| `data-design-gap` | number | 0 | 96 |
| `data-design-image-ratio` | enum |  |  |
| `data-design-typography` | textToken |  |  |
| `data-design-color` | colorToken |  |  |
| `data-design-visibility` | visibility |  |  |
| `data-design-repeat` | boolean |  |  |
| `data-design-facet-search` | boolean |  |  |

Registered CSS tokens: `--presentation-gap`, `--presentation-columns`, `--presentation-radius`, `--presentation-type-scale`, `--presentation-color-accent`, `--presentation-color-surface`.

## 7. Styling

- Stylesheets are plain CSS, scoped by the compiler to your presentation.

- Motion is CSS only: `@keyframes`, scroll-driven timelines (`animation-timeline`), `@container`, `@layer` and filters (`filter`, `backdrop-filter`). The compiler adds a `prefers-reduced-motion: reduce` guard, so authored and preset motion stops when the visitor asks for less motion.

- thresho motion presets are classes: `thresho-fade-in`, `thresho-rise`, `thresho-parallax`, `thresho-reveal`, `thresho-marquee`. Add one to a `className` and the compiler emits its keyframes and scoped class.

- `html` and `body` selectors are rejected. Use `:root`: it is the page root and always fills the viewport.

- Full-bleed pages: put the page background on `:root`, and constrain content with an inner wrapper, for example `:root{background:#f8faf8}` and `.shell{max-width:1360px;margin:auto}`.

- No remote CSS or fonts, data URLs, javascript URLs, uploaded SVG or external asset fetches.

## 8. Fonts and media

- Declare optional `fonts` slots with `slot`, an approved `family` (`manrope`, `playfair-display`), `weight`, `style`, `display` and `preload`. The compiler emits `--presentation-font-<slot>` and the published page preloads a bound slot.

- Declare optional `media` slots with `slot`, `kind` (`image` or `video`), `backend` (`r2` or `stream`), an optional image `poster` and an optional video `hero` flag. `Presentation.Image` and `Presentation.Video` must name a declared slot of the matching kind.

- A media slot never names a URL or an asset identity. The trusted workspace binds it, and the binding must stay on the platform media origin.

## 9. Content fields and disclosures

Text the merchant controls belongs in `content`, never hard-coded in markup. The product page return policy is the `return_policy` field: render it with `<Content.Text field="return_policy" />`. When a merchant has not written a policy, the field is empty and nothing is shown; never write a policy into the source.

## 10. Limits

| Limit | Value |
| --- | --- |
| Bytes per source file | 65536 |
| Total expanded source bytes | 524288 |
| Package markup nodes | 16384 |
| Package bytes after JSON escaping | 3145728 |
| Stylesheets | 64 |
| Code points per content value | 10000 |
| Locales per package | 8 |
| Markup nodes per route | 2048 |
| Nesting depth per route | 32 |
| Design descriptors | 2048 |
| Design edits per change | 32 |
| Diff entries per change | 512 |
| ZIP compressed bytes | 1048576 |
| ZIP expanded bytes | 524288 |
| Diagnostics returned | 100 |
| Characters per diagnostic message | 512 |
| Bytes (UTF-8) per structural change instruction | 4000 |

## 11. Diagnostics

Each diagnostic has `code`, `message`, `file`, `line` and `column`. A package with any diagnostic cannot be validated, previewed or reviewed.

| Code | What to fix |
| --- | --- |
| `INVALID_PACKAGE` | The manifest or file map is malformed. Check kind, formatVersion, id, name, journeys, routes, content and every file path against schema/source.schema.json. |
| `INVALID_ROUTE` | A route path, entry, capability or role is not accepted, a protected path is used without the role that owns it, a route path ends with a slash, or the journey rules below are not met. The message names the rule. |
| `INVALID_LOCALE` | A locale tag, the supported locale list, a locale prefix on an authored route, or a per-locale content map is not accepted. Use a lowercase language tag with an optional uppercase region, list 1 to 8 unique tags, include the default tag, and let thresho own the first path segment for every declared tag. |
| `INVALID_MEDIA` | A media slot declaration, a Presentation.Image or Presentation.Video slot, or a media binding is not accepted. Declare 1 to 32 unique slots with a kind and a backend, name a declared image slot as the poster, and keep every binding URL on the platform media origin. |
| `INVALID_FONT` | A font slot declaration or a font binding is not accepted. Declare 1 to 8 unique slots with an approved family, a weight in steps of 100, a style, a display value and a preload flag. |
| `UNSUPPORTED_SOURCE` | A construct outside the bounded source language was used: imports other than @thresho/site-sdk and local components, hooks, handlers, function calls, spreads, dynamic names, network access. Replace it with an SDK component or plain markup. |
| `INVALID_BINDING` | An SDK component is used where its data is not available, with an unknown prop, or outside its allowed parent. Move it inside the right route or parent, or remove the prop. |
| `LIMIT_EXCEEDED` | A file, stylesheet, content field or total size limit was exceeded. Split or shorten the source. |
| `SOURCE_BYTES_EXCEEDED` | The package source is larger than 512 KiB in total. Remove or shorten source files. |
| `SOURCE_FILE_BYTES_EXCEEDED` | One source file is larger than 64 KiB. Split it into smaller files. |
| `PACKAGE_NODES_EXCEEDED` | The package compiled view has more than 16384 nodes. Remove sections or share components. |
| `PACKAGE_BYTES_EXCEEDED` | The package artifact is larger than 3 MiB after JSON escaping. Shorten long text or remove repeated content. |
| `ROUTE_NODES_EXCEEDED` | One route has more than 2048 compiled nodes. Split the page or remove sections. |
| `ROUTE_DEPTH_EXCEEDED` | One route nests more than 32 elements deep. Flatten the markup. |
| `RESERVED_ELEMENT_ID` | An element id starts with the reserved prefix site-source-. Rename it; thresho keeps that prefix for its hydration payload and root. |
| `FORM_INVALID` | A form declaration or placement is not accepted. Check the form kind, its required email, date or rating field, the form id, and that every placing Form tag names a declared form of the same kind. |
| `FORM_FIELD_BOUND` | A form or field value is outside its bound. Check the field count, option count, route count, text length, date, time and numeric range. |
| `FORM_FIELD_KIND_UNSUPPORTED` | A form field kind is not supported. Use text, email, tel, url, number, textarea, select, checkbox, radio-group, date or time. |
| `FORM_FIELD_NAME_RESERVED` | A form field name is reserved for thresho or for the renderer. Rename it. |
| `FORM_PHI_FIELD_REFUSED` | A form field collects health, identity or payment data. Remove it; a thresho form cannot collect special-category data. |
| `FORM_CONSENT_REQUIRED` | Every form needs a consent label and a privacyPath that names a declared page on the same site. |
| `EXTENSION_INVALID` | The extension surface names something the package does not declare, repeats an entry, uses an unknown key, or breaks a bound. Name only declared content keys, declared image slots, registered tokens, explicit nodeIds, registered block names and free route patterns. |
| `EXTENSION_PROTECTED_SURFACE` | The extension surface reaches a protected surface. A region cannot sit on a cart, checkout, confirmation or account route, cannot name a Checkout control or a required-disclosure control, and cannot target a protected control or a node inside one. An anchor cannot target a protected control. |
| `EXTENSION_ANCHOR_UNKNOWN` | An anchor names a route the manifest does not declare, a nodeId that is not authored on that route, or a property the compiler does not register. Add the route, pin the nodeId in the source, and use a registered data-design property. |
| `EXTENSION_ANCHOR_UNPATCHABLE` | An anchor names a registered property with no patchable literal at that node. A generated or instance-scoped identity, a non-literal value, a shared source location or a duplicate declaration cannot be patched; move the value to a single literal at the anchored node. |
| `TOKEN_SINK_REFUSED` | A registered presentation token reaches a CSS property its kind does not allow, directly or through a custom-property alias. Use a colour token only in a colour property, a spacing token only in gap, margin or padding, a radius token only in border-radius, the type token only in font-size, and the layout token only in a column property. |

## 12. The validation loop

1. Check the source without saving: `POST /api/studio/sites/{siteId}/presentation/source-checks` on your thresho operator host, signed in, with the X-CSRF-Token header from your session, with body `{"source": {"manifest": {...}, "files": {...}}}`, or use Check without saving in the workspace Import panel.

2. Fix every diagnostic and every review blocker in the response, then check again.

3. Import the source as a package, save site settings, preview it, then submit it for review.

The response lists `issues`, `requirements`, the derived `journey`, the `compile` identity and `reviewReadiness` with its `blockers`.

## 13. Instructions to give a code-writing tool

Copy this block, then paste the diagnostics you get back after each check.

```text

Write a thresho format 2 presentation package. Follow AUTHORING.md exactly.

Output one JSON object {"manifest": {...}, "files": {"src/...": "..."}} and nothing else.

Use only @thresho/site-sdk components and props from section 5, plain markup and scoped CSS.

Declare a role on every route and meet every journey rule in section 3.

Never write catalog data, prices, policies, identifiers, URLs, scripts, hooks or event handlers.

When given diagnostics, change only what each diagnostic names and return the complete JSON again.

```
