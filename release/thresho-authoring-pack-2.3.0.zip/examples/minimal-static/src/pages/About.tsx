import { Content } from "@thresho/site-sdk";
export default function About() { return <main nodeId="about-main"><section nodeId="about-section"><h1>About us</h1><p><Content.Text field="about.body" /></p><a href="/">Home</a></section></main>; }
