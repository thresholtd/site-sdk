import { Content } from '@thresho/site-sdk'; import Shell from '../components/Shell';
export default function Home() { return <Shell nodeId="home-shell"><section className="home-hero" nodeId="home-hero"><p className="home-eyebrow">Connected catalog</p><h1><Content.Text field="title" /></h1><p><Content.Text field="introduction" /></p><a href="/shop">Browse the catalog</a></section></Shell>; }
