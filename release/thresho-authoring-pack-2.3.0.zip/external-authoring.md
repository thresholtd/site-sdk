# External authoring boundary

This pack is a versioned schema, vocabulary, limits, diagnostics, and examples kit. It does not contain or license a standalone thresho compiler, preview runtime, catalog adapter, transaction implementation, or publication tool.

You may author the bounded format 2 source format in any text editor and use the included JSON schema for early feedback. A local HTML, React, or browser rendering is not authoritative because it does not run the pinned thresho compiler, trusted business components, site-local catalog configuration, managed assets, or isolated preview bridge.

Check every source revision with the source-check route or Check without saving in the authenticated thresho workspace, then import it. The compiler diagnostics, normalized source identity, connected read-only preview, and review submission shown there are the authority for supported-source acceptance. Unsupported constructs reject; they are not silently removed or approximated. AUTHORING.md is the complete guide.
