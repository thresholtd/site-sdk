# format 2 authoring pack validator

1. Keep the manifest at thresho.site.json and source files under src/. Validate the manifest and file map against schema/source.schema.json for early feedback.
2. Use only format 2 SDK components, registered design properties, and the route roles and journey rules in AUTHORING.md.
3. Check the source without saving: POST /api/studio/sites/{siteId}/presentation/source-checks on your thresho operator host, signed in, with the X-CSRF-Token header from your session, or Check without saving in the workspace Import panel. The response is the authority.
4. Treat every diagnostic and every review blocker as a failed validation until the source is corrected.
5. After every edit, check again and compare the compile identity in the response.
6. Import the source as a package only when the check reports no issues; never execute uploaded files or install dependencies.

The compiler accepts data, not arbitrary React, JavaScript, npm dependencies, network requests, executable uploads, forms with side effects, or external fetch instructions.
