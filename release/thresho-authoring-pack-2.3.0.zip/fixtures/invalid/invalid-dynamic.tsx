export default function Bad(props) { return <main>{props.children}</main>; }
