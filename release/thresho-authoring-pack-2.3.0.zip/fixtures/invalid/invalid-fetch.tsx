export default function Bad() { return <main>{fetch("https://example.invalid/data")}</main>; }
