export default function Bad() { return <button onClick={() => true}>Run</button>; }
