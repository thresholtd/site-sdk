import React from "react"; export default function Bad() { return <main />; }
