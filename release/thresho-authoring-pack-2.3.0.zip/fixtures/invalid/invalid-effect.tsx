import { useEffect } from "react"; export default function Bad() { useEffect(() => undefined, []); return <main />; }
